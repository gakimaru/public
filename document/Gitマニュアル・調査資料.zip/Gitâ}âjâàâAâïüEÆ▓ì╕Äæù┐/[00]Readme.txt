    ≪Gitマニュアル・調査資料について≫    2013/7/19

ファイル構成は下記の通り。

    [Gitマニュアル・調査資料]
     |
     |- [00]Readme.txt
     |- [01]SubversionユーザーのためのGit活用の勧め.pptx
     |- [02]TortoiseGitセットアップ手順.docx
     |- [03]TortoiseGitのhttp(s)通信およびパスワードの記憶と破棄について.docx
     |- [04]TortoiseGitのSSH通信およびパスフレーズの記憶と破棄について.docx
     |- [05]TortoiseGitによるSSH通信用秘密鍵・公開鍵生成手順.docx
     |- [06]TortoiseGitの使い方とワークフロー.docx
     |- [資料01]Gitサーバー比較.xlsx
     |- [資料02]Gitに関する推奨書籍.docx
     |
     |- [Tools]
     |   |
     |   `-[git_erase_wincred_all] ... TortoiseGit が wincred で記憶する
     |                                 ユーザー認証情報を一括削除する為の
     |                                 ごく簡単なツール
     `[PDF]
       |
       |- ... 上記のドキュメントをPDFファイル化したもの


以上
